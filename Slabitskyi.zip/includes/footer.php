<!-- static/includes/footer.php -->
<footer>
    <div class="working-hours">
        <img src="../static/images/main/timelogo.png" alt="">
        <p>Ми працюємо</p>
        <p>Пн - Сб: 8:00 - 18:00</p>
        <p>Неділя - вихідний</p>
    </div>
    <div class="copyright">
        <p>Copyright © 2025 Coffee Time. All Rights Reserved.</p>
    </div>
</footer>
