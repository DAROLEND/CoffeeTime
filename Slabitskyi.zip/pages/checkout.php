<?php
session_start();
require_once '../db/db.php';

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: ../pages/index.php");
    exit();
}

if (!isset($_SESSION['user']) || !is_array($_SESSION['user'])) {
    header("Location: ../forms/login.php");
    exit();
}

$user = $_SESSION['user'];
$cart = $_SESSION['cart'];
$total = 0;

foreach ($cart as $item) {
    $total += $item['price'] * $item['quantity'];
}

$firstName = (!empty($_POST['first_name'])) ? $_POST['first_name'] : ($user['client_name'] ?? '');
$lastName = (!empty($_POST['last_name'])) ? $_POST['last_name'] : ($user['client_surname'] ?? '');
$phoneFromProfile = (!empty($_POST['phone'])) ? $_POST['phone'] : ($user['client_PhoneNumber'] ?? '');


$successMessage = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);
    $time = trim($_POST['ready_time']);
    $comment = trim($_POST['comment']);
    $payment = $_POST['payment'] ?? '';

    if (!empty($firstName) && !empty($lastName) && !empty($phone) && !empty($time) && !empty($payment)) {
        $stmt = $conn->prepare("INSERT INTO orders (user_id, total, delivery_address, phone, status, customer_name, customer_surname, comment, ready_time, payment_method) VALUES (?, ?, '', ?, 'pending', ?, ?, ?, ?, ?)");
        $stmt->bind_param("idssssss", $user['client_id'], $total, $phone, $firstName, $lastName, $comment, $time, $payment);

        if ($stmt->execute()) {
            $orderId = $stmt->insert_id;

            foreach ($cart as $item) {
                $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("iiid", $orderId, $item['id'], $item['quantity'], $item['price']);
                $stmt->execute();
            }

            unset($_SESSION['cart']);
            $successMessage = "✅ Ваше замовлення успішно оформлено!";
        } else {
            $successMessage = "❌ Помилка при оформленні: " . $stmt->error;
        }
    } else {
        $successMessage = "❌ Усі обов’язкові поля мають бути заповнені!";
    }
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Оформлення замовлення</title>
    <link rel="stylesheet" href="../static/css/style.css">
    <link rel="stylesheet" href="../static/css/checkout.css">
</head>
<body>
<?php 
$page = 'checkout';
include '../includes/header.php'; 
?>
<main>
    <section class="checkout">
        <h1>Оформлення замовлення</h1>

        <?php if (!empty($successMessage)): ?>
            <p class="checkout-message"><?= htmlspecialchars($successMessage) ?></p>
        <?php endif; ?>
       <?php echo '<pre>';
print_r($_SESSION['user']);
echo '</pre>';?>

        <form method="post">
            <label for="first_name">Ім’я:</label>
            <input type="text" id="first_name" name="first_name" value="<?= htmlspecialchars($firstName) ?>" required>

            <label for="last_name">Прізвище:</label>
            <input type="text" id="last_name" name="last_name" value="<?= htmlspecialchars($lastName) ?>" required>

            <label for="phone">Телефон:</label>
            <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($phoneFromProfile) ?>" required>

            <label for="ready_time">Година готовності:</label>
            <select name="ready_time" id="ready_time" required>
                <option value="ASAP">Якнайшвидше</option>
                <?php
                for ($h = 9; $h <= 20; $h++) {
                    echo "<option value='{$h}:00'>{$h}:00</option>";
                    echo "<option value='{$h}:30'>{$h}:30</option>";
                }
                ?>
            </select>

            <label for="comment">Коментар:</label>
            <textarea name="comment" id="comment" rows="3" placeholder="Додаткові побажання..."></textarea>

            <label for="payment">Спосіб оплати:</label>
            <select name="payment" id="payment" required>
                <option value="">Оберіть спосіб</option>
                <option value="apple_pay">Apple Pay</option>
                <option value="google_pay">Google Pay</option>
                <option value="card_online">Visa/Mastercard</option>
                <option value="cash_on_pickup">Оплата при отриманні</option>
            </select>

            <div class="cart-summary">
                <h3>Ваше замовлення:</h3>
                <ul>
                    <?php foreach ($cart as $item): ?>
                        <li class="cart-item">
                            <img src="<?= htmlspecialchars($item['image']) ?>" alt="<?= htmlspecialchars($item['name']) ?>">
                            <div class="cart-info">
                                <span><?= htmlspecialchars($item['name']) ?> (<?= $item['quantity'] ?> шт.)</span>
                                <span><?= number_format($item['price'], 2) ?> грн</span>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <p><strong>Загальна сума: <?= number_format($total, 2) ?> грн</strong></p>
            </div>

            <button type="submit">Оформити замовлення</button>
        </form>
    </section>
</main>
<?php include '../includes/footer.php'; ?>
</body>
</html>
