<?php
session_start();
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Coffee Time</title>
    <link rel="stylesheet" href="../static/css/style.css">
</head>
<body>
<?php 
$page = 'contact';
include '../includes/header.php'; 
?>
    <main>
    </main>
    <?php include '../includes/footer.php'; ?>
</body>
</html>