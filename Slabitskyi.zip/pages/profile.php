<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require_once '../db/db.php';

if (!isset($_SESSION['user']) || !is_array($_SESSION['user'])) {
    header("Location: ../pages/index.php");
    exit();
}

$user = $_SESSION['user'];
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = trim($_POST['first_name']);
    $lastName = trim($_POST['last_name']);
    $phone = trim($_POST['phone']);

    $userId = $user['client_id'];

    // Оновлення в базі
    $stmt = $conn->prepare("UPDATE users SET client_name = ?, client_surname = ?, client_PhoneNumber = ? WHERE client_id = ?");
    $stmt->bind_param("sssi", $firstName, $lastName, $phone, $userId);

    if ($stmt->execute()) {
        // Оновлення в сесії
        $_SESSION['user']['client_name'] = $firstName;
        $_SESSION['user']['client_surname'] = $lastName;
        $_SESSION['user']['client_PhoneNumber'] = $phone;
        $user = $_SESSION['user'];

        $successMessage = "✅ Дані успішно оновлено!";
    } else {
        $successMessage = "❌ Помилка під час оновлення: " . $stmt->error;
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Профіль користувача</title>
    <link rel="stylesheet" href="../static/css/style.css">
    <link rel="stylesheet" href="../static/css/profile.css">
</head>
<body>
<?php 
$page = 'profile';
include '../includes/header.php'; 
?>
<main>
    <section class="profile">
        <h1>Профіль користувача</h1>

        <?php if (!empty($successMessage)): ?>
            <p style="color: green;"><?= htmlspecialchars($successMessage) ?></p>
        <?php endif; ?>

        <form method="post">
            <label for="first_name">Ім’я:</label>
            <input type="text" id="first_name" name="first_name" value="<?= htmlspecialchars($user['client_name'] ?? '') ?>" required>

            <label for="last_name">Прізвище:</label>
            <input type="text" id="last_name" name="last_name" value="<?= htmlspecialchars($user['client_surname'] ?? '') ?>" required>

            <label for="phone">Номер телефону:</label>
            <input type="tel" id="phone" name="phone" value="<?= htmlspecialchars($user['client_PhoneNumber'] ?? '') ?>" required>

            <button type="submit">Зберегти зміни</button>
            <a href="../pages/logout.php" class="auth-link-button logout-button">Вийти</a>

        </form>
    </section>
</main>
<?php include '../includes/footer.php'; ?>
</body>
</html>
