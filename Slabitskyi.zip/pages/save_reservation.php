<?php
session_start();
include '../db/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tables = explode(',', $_POST['selected_tables'] ?? '');
    $location = 'indoor';

    // Якщо користувач авторизований — беремо дані з сесії
    if (isset($_SESSION['user']) && is_array($_SESSION['user'])) {
        $user = $_SESSION['user'];
        $name = $user['client_name'] ?? '';
        $surname = $user['client_surname'] ?? '';
        $phone = $user['client_PhoneNumber'] ?? '';
    } else {
        // Інакше — перевіряємо поля з форми
        $name = trim($_POST['name'] ?? '');
        $surname = trim($_POST['surname'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        if (empty($name) || empty($surname) || empty($phone)) {
            echo "❌ Всі поля обов’язкові для заповнення!";
            exit();
        }
    }

    // Збереження бронювання
    foreach ($tables as $table) {
        $table = intval($table);
        $check = mysqli_query($conn, "SELECT * FROM reservations WHERE table_number = $table AND location = '$location'");
        if (mysqli_num_rows($check) === 0) {
            mysqli_query($conn, "INSERT INTO reservations (table_number, location, client_name, client_surname, client_phone) 
                VALUES ($table, '$location', '$name', '$surname', '$phone')");
        }
    }

    header("Location: reserve_success.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Бронювання столика</title>
    <link rel="stylesheet" href="../static/css/style.css">
</head>
<body>
    <h1>Бронювання столика (зал)</h1>

    <?php if (!isset($_SESSION['user'])): ?>
    <form method="post" id="reservation-form">
        <label for="name">Ім’я:</label>
        <input type="text" name="name" id="name" required>

        <label for="surname">Прізвище:</label>
        <input type="text" name="surname" id="surname" required>

        <label for="phone">Телефон:</label>
        <input type="tel" name="phone" id="phone" required>

        <input type="hidden" name="selected_tables" id="selected_tables">
        <button type="submit">Підтвердити бронювання</button>
    </form>
    <?php else: ?>
    <form method="post" id="reservation-form">
        <input type="hidden" name="selected_tables" id="selected_tables">
        <button type="submit">Підтвердити бронювання</button>
    </form>
    <?php endif; ?>

    <script src="../static/js/save_reservation.js"></script>
    </script>
</body>
</html>
